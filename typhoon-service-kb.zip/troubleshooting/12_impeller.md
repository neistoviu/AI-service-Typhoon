# Крыльчатка — Impeller

**Частота:** ★★☆☆☆ (~5 кейсов) | **Модели:** 5kg, 2.5kg Cyclone

Решение: замена крыльчатки.
Michal Jakoubek (2.5kg Cyclone), Colombani (5kg+20e), Nicki Sturrock (5kg), Nort van Hulten (5kg), Cubby house (5kg, болты в улитке).
