# Частотник (ПЧ) — VFD

**Частота:** ★★★☆☆ (~8 кейсов) | **Модели:** 20 gas, 5kg, 20 electro, 10 electro

## Диагностика сгоревшего ПЧ
1. Проверить провода → 2. Откинуть питание ПЧ → 3. Ростер включается без ПЧ = замена

## Кейсы
James Price (20 gas, после 350кг), First Crack (20 electro), Erin Maguire (20 gas), Momentum-C (20 electro), Efficiense Oy (5kg фильтр), Velvet (10 electro), Guzo (20 electro).

## Ошибка E001
Daniel Baum (10 gas): A006 +2сек → ⚠️ частичное решение

## Потеря фазы
TRE-359 (2.5kg Cyclone): проверка подключения с электриком
