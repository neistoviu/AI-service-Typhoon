# Typhoon Roasters — Service Knowledge Base

AI-powered service assistant knowledge base for Typhoon coffee roasters.

## Structure
- `troubleshooting/` — Problem → Diagnosis → Solution guides (18 categories)
- `standard_procedures/` — Step-by-step repair/check instructions
- `manuals/` — Extracted content from equipment manuals
- `models/` — Model-specific known issues

## Models Covered
Typhoon 2.5kg, 5kg, 10 electro, 10 gas, 10 PRO, 20 electro, 20 gas, 30 electro

## Update Cycle
Monthly sync from Monday.com → ⚙️ service tasks → "done cases"

## Last Updated: 2026-03-18 | v2.0
